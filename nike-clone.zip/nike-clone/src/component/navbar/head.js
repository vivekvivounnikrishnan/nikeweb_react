import React from 'react';
import imag1 from '../navbar/Screenshot 2024-04-11 153535.png';
function Head1() {
    return (
    <>
         <img style={{paddingLeft:"200px",marginTop:"50px",width:"90%",}}src={imag1}/>
    <div style={{textAlign:"center"}}>
   <h2 style={{fontSize:"60px"}}><b>DIAMOND SHORTS &</b></h2>
   <h2 style={{fontSize:"60px"}}><b> STADIUM 90S</b></h2>
   <h3 style={{fontSize:"20px"}}>Our shoe images can be used for a variety of purposes, from e-commerce websites to marketing collateral. </h3>
   <button type="button"style={{ width:"110px",height:"50px",borderRadius:"30px",marginTop:'20px',marginBottom:"20px",backgroundColor:"black",color:"white",marginRight:'10px'}}><b>Shope now</b></button>
    </div>
    </> 
  );
}
export default Head1;