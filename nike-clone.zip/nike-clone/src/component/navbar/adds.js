import React from 'react'

export default function adds() {
  return (
    <div>adds</div>
  )
}
