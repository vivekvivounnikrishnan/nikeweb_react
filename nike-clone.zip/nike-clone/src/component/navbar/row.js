import React from 'react'
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import img1 from '../navbar/pexels-melvin-buezo-2529148.jpg'
import img2 from '../navbar/pexels-ray-piedra-1537671(1).jpg'
 function Row1() {
  return (
   <>
        <Container>
            <Row>
                <Col xs={4} md={4}>
                    <h1 style={{marginTop:"40px",fontSize:'30px'}}>Trend Alert</h1>
                    <img src={img1}style={{width:'500px'}}></img>
                    <h2>Nike</h2>
                    <p>Rs:12000 80%off</p>
                    <button type="button"style={{ width:"110px",height:"50px",borderRadius:"30px",marginTop:'20px',marginBottom:"20px",backgroundColor:"black",color:"white"}}><b>Shope</b></button>
                </Col>
                <Col xs={4} md={4}>
                    
                    <img src={img2}style={{width:'500px',marginTop:'85px',height:'625px'}}></img>
                    <h2>Nike</h2>
                    <p>Rs:12000 80%off</p>
                    <button type="button"style={{ width:"110px",height:"50px",borderRadius:"30px",marginTop:'20px',marginBottom:"20px",backgroundColor:"black",color:"white"}}><b>Shope</b></button>
                </Col>
                <Col xs={4} md={4}>
                    
                    <img src={img1}style={{width:'500px',marginTop:'85px'}}></img>
                    <h2>Nike</h2>
                    <p>Rs:12000 80%off</p>
                    <button type="button"style={{ width:"110px",height:"50px",borderRadius:"30px",marginTop:'20px',marginBottom:"20px",backgroundColor:"black",color:"white"}}><b>Shope</b></button>
                </Col>

            </Row>
        </Container>
   </>

   
  );
}
export default Row1;