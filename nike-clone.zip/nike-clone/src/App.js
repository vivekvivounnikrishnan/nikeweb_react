import './App.css';
import Navbar from './component/navbar/navbar';
import Carousel from './component/navbar/background';
import Title1 from './component/navbar/title';
import Card1 from './component/navbar/card';
import Row1 from './component/navbar/row';
import Head1 from './component/navbar/head';
import Adds from './component/navbar/adds'
import Foot1 from './component/navbar/foot1';
import Footer from './component/navbar/footer/footer';
function App() {
  return (
    <div className="App">
    <Navbar/>
    <Carousel/>
    <Title1/>
    <Card1/>
    <Row1/>
    <Head1/>
    <Adds/>
    <Foot1/>
    <Footer/>

    </div>
  );
}

export default App;
