import React from 'react'
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
 function Foot1() {
  return (
   <>
   <div className='col'style={{paddingLeft:'150px',marginTop:'50px'}}>
   <Row>
            <Col>
               <ul style={{listStyle:'none'}}>
                    <h4>icon</h4>
                    <li>Air force 1</li>
                    <li>Air force 1</li>
                    <li>Air force 1</li>
                    <li>Air force 1</li>
                    <li>Air force 1</li>
                </ul>
            </Col>
        <Col>
            <ul style={{listStyle:'none'}}>
                <h4>Shoes</h4>
                <li>Air force 1</li>
                <li>Air force 1</li>
                <li>Air force 1</li>
                <li>Air force 1</li>
                <li>Air force 1</li>
            </ul>
        </Col>
        <Col>
            <ul style={{listStyle:'none'}}>
                <h4>Clothings</h4>
                <li>Air force 1</li>
                <li>Air force 1</li>
                <li>Air force 1</li>
                <li>Air force 1</li>
                <li>Air force 1</li>
            </ul>
        </Col>

        <Col>
            <ul style={{listStyle:'none'}}>
                <h4>Kids</h4>
                <li>Air force 1</li>
                <li>Air force 1</li>
                <li>Air force 1</li>
                <li>Air force 1</li>
                <li>Air force 1</li>
            </ul>
        </Col>
   </Row>
   </div>
   </> 
  
  )
}
export default Foot1